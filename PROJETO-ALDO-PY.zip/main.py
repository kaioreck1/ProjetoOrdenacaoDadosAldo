import concurrent.futures
import threading
import time


# Função para ordenar os dados usando o algoritmo quicksort
def quick_sort(arr):

  
  # Se a lista estiver vazia ou tiver apenas um elemento, não precisa ordenar
  if len(arr) <= 1:
    return arr

  
  # Seleciona um número central da lista como pivô
  pivot = arr[len(arr) // 2]

  
  # Divide a lista em três partes: menores, iguais e maiores que o pivô
  esquerda = [x for x in arr if x < pivot]
  meio = [x for x in arr if x == pivot]
  direita = [x for x in arr if x > pivot]

  
  # Combina recursivamente as listas ordenadas (menores, iguais, maiores) e retorna o resultado
  return quick_sort(esquerda) + meio + quick_sort(direita)


# Função para escrever os dados ordenados em um arquivo 
def escrever_dados_ordenados(nome_arquivo, dados):
  with open(nome_arquivo, "w") as arquivo:
    for item in dados:
      arquivo.write(str(item) + "\n")


# Função para escrever o tempo de execução em um arquivo
def escrever_tempo_execucao(nome_arquivo, tempo_execucao):
  with open(nome_arquivo, "w") as arquivo:
    arquivo.write(
        "O tempo que levou para ordenar usando threads foi de {:.6f} segundos".
        format(tempo_execucao))


# Função para ordenar dados em uma thread
def ordenar_dados(dados):
  return quick_sort(dados)


# Função para calcular o tempo de execução
def analisar_desempenho(tempo_inicio, tempo_fim):
  return tempo_fim - tempo_inicio


if __name__ == "__main__":
  # Solicita ao usuário o nome do arquivo que contém os dados a serem ordenados
  nome_arquivo = input(
      "Digite o nome do arquivo que contém os dados a serem ordenados: ")

  
  try:
    # Lê os dados do arquivo
    with open(nome_arquivo, "r") as arquivo:
      dados = [linha.strip() for linha in arquivo]
      
      # Converte strings para inteiros, se possível
      dados = [int(item) if item.isdigit() else item for item in dados]
  except FileNotFoundError:
    print(
        "O arquivo não foi encontrado. Por favor, certifique-se de digitar o nome correto do arquivo."
    )
  else:
    
    # Pergunta pro usuário se deseja rodar o código
    executar_codigo = input(
        "Gostaria de executar este código? (sim/não): ").lower()
    if executar_codigo.strip() == "sim":

      # Pergunta pro usuário quantas threads deseja utilizar
      num_threads = int(
          input(
              "Quantas threads você gostaria de usar para ordenar os dados? "))

      # Divide os dados em partes iguais
      tamanho_parte = len(dados) // num_threads
      partes = [
          dados[i:i + tamanho_parte]
          for i in range(0, len(dados), tamanho_parte)
      ]

      
      # Inicia a ThreadPoolExecutor para paralelizar a ordenação dos dados
      with concurrent.futures.ThreadPoolExecutor(
          max_workers=num_threads) as executor:
        
        # Submete cada parte dos dados para ser ordenada em uma thread
        futuros = [executor.submit(ordenar_dados, parte) for parte in partes]

        # Mostra os resultados ordenados de cada thread
        resultados = [
            futuro.result()
            for futuro in concurrent.futures.as_completed(futuros)
        ]

      # Escreve os dados ordenados em arquivo
      escrever_dados_ordenados("dados_ordenados_com_threads.txt", resultados)
      print("Os dados ordenados usando threads foram salvos em um arquivo.")

      
      # Grava o tempo do tipo paralela
      tempo_inicio = time.time()
      dados_ordenados = quick_sort(dados)
      tempo_fim = time.time()
      tempo_execucao_paralelo = analisar_desempenho(tempo_inicio, tempo_fim)

      # Escreve o tempo de execução em um arquivo
      escrever_tempo_execucao("tempo_execucao.txt",
                              tempo_execucao_paralelo)

      # Mostra os dados ordenados pela tipo sequencial em um arquivo
      escrever_dados_ordenados("dados_ordenados_threads.txt",
                               dados_ordenados)
      print("Os dados ordenados foram salvos em um arquivo.")
      print("O tempo de execução foi de:",
            tempo_execucao_paralelo)
    else:
      print("O código não foi executado. Encerrando.")
